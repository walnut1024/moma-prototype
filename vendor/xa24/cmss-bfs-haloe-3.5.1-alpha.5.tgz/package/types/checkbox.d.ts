/*
 * @Description: Stay hungry，Stay foolish
 * @Author: ''
 * @Date: 2023-06-09 08:38:08
 * @LastEditTime: 2023-09-05 14:53:56
 * @LastEditors: ''
 */
import type { DefineComponent } from 'vue';

export declare const Checkbox : DefineComponent<{
  /**
   * 只在单独使用时有效。可以使用 v-model 双向绑定数据
   * @default false
   */
  value?: boolean
  /**
   * 只在组合使用时有效。指定当前选项的 value 值，组合会自动判断当前选择的项目
   */
  label?: string | number
  /**
   * 是否禁用当前项
   * @default false
   */
  disabled?: boolean
  /**
   * 选中时的值，当使用类似 1 和 0 来判断是否选中时会很有用
   * @default true
   */
  'true-value'?: string | number | boolean
  /**
   * 没有选中时的值，当使用类似 1 和 0 来判断是否选中时会很有用
   * @default false
   */
  'false-value'?: string | number | boolean
  /**
   * 在选项状态发生改变时触发，返回当前状态。通过修改外部的数据改变时不会触发
   */
  $emit(eventName: 'on-change', arg: string | number | boolean): ()=>any
}>

export declare const CheckboxGroup :DefineComponent <{
  /**
   * 指定当前选中的项目数据。可以使用 v-model 双向绑定数据
   */
  value?: string | number
  /**
   * 可选值为 button 或不填，为 button 时使用按钮样式
   */
  type?: string
  /**
   * 尺寸，可选值为base、middle、small或者不设置
   */
  size?: '' | 'base' | 'middle' | 'small'
  /**
   * 在选项状态发生改变时触发，返回当前选中的项。通过修改外部的数据改变时不会触发
   */
  $emit(eventName: 'on-change', ...args: Array<string | number | boolean>): (args:Array<string | number | boolean>)=>any
}>
