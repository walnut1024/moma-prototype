import type { DefineComponent } from 'vue';

export declare const Footer : DefineComponent<{
}>
