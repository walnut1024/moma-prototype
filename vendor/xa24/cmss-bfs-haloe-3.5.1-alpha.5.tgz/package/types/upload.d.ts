import type { DefineComponent } from 'vue';

interface file {
  name: string,
  url: string,
}
export declare const  Upload: DefineComponent <{
  /**
   * 上传的地址
   */
  action: string;
  /**
   * 设置上传的请求头部
   * @default []
   */
  headers?: object;
  /**
   * 是否支持多选文件
   * @default false
   */
  multiple?: boolean;
  /**
   * 上传时附带的额外参数
   */
  data?: object;
  /**
   * 上传的文件字段名
   * @default file
   */
  name?: string;
  /**
   * 标题集合，顺序从左至右
   * 默认['源列表', '目的列表']
   */
  titles?: Boolean;
  /**
   * 支持发送 cookie 凭证信息
   * 默认：false
   */
  'with-credentials'?: boolean;
  /**
   * 是否显示已上传文件列表
   * 默认：true
   */
  'show-upload-list'?: boolean;
  /**
   * 上传控件的类型，可选值为 select（点击选择），drag（支持拖拽），drag-1（支持拖拽）
   * 默认：select
   */
  type?: 'select' | 'drag' | 'drag-1';
  /**
   * 支持的文件类型，与 accept 不同的是，format 是识别文件的后缀名，accept 为 input 标签原生的 accept 属性，会在选择文件时过滤，可以两者结合使用
   */
  format?: string[];
  /**
   * 接受上传的文件类型
   */
  accept?: string;
  /**
   * 文件大小限制，单位 kb
   */
  'max-size'?: number;
  /**
   * 默认已上传的文件列表，例如：```[{name: 'img1.jpg', url: 'http://www.xxx.com/img1.jpg'}, {name: 'img2.jpg', url: 'http://www.xxx.com/img2.jpg'}]```
   * 默认：false
   */
  'default-file-list'?: file[];
  /**
   * 是否支持粘贴上传文件
   * @default false
   */
  paste?: boolean;
  /**
   * 是否禁用
   * @default false
   */
  disabled?: boolean;
  /**
   * 是否开启选择文件夹，部分浏览器适用
   * @default false
   */
  webkitdirectory?: boolean;
  /**
   * 上传文件之前的钩子，参数为上传的文件，若返回 false 或者 Promise 则停止上传
   */
  'before-upload'?: Function;
  /**
   * 文件上传时的钩子，返回字段为 event, file, fileList
   */
  'on-progress'?: Function;
  /**
   * 文件上传成功时的钩子，返回字段为 response, file, fileList
   */
  'on-success'?: Function;

  /**
   * 文件上传失败时的钩子，返回字段为 error, file, fileList
   */
  'on-error'?: Function;

  /**
   * 点击已上传的文件链接时的钩子，返回字段为 file， 可以通过 file.response 拿到服务端返回数据
   */
  'on-preview'?: Function;

  /**
   * 文件列表移除文件时的钩子，返回字段为 file, fileList
   */
  'on-remove'?: Function;

  /**
   * 文件格式验证失败时的钩子，返回字段为 file, fileList
   */
  'on-format-error'?: Function;

  /**
   * 文件超出指定大小限制时的钩子，返回字段为 file, fileList
   */
  'on-exceeded-size'?: Function;
  /**
   * 插槽
   */
  'v-slots'?: {
    /**
     * 触发上传组件的控件
     */
    default?: () => any;

    /**
     * 辅助提示内容
     */
    tip?: () => any;
    /**
     * 在drag-1模式下可自定义额外的显示内容
     */
    fileDetails?: () => any;
  };
}>
