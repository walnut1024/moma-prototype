import type { DefineComponent } from 'vue';

export declare const Breadcrumbs: DefineComponent<{
}>
