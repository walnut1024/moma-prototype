import Vue, { VNode } from 'vue';
import type { DefineComponent } from 'vue';
export declare const Tag: DefineComponent<{
  /**
   * tag尺寸
   * @default ''
   */
  size?: 'default'|'medium'|'large';
  /**
   * 使用样式二
   * @default false
   */
  dark?: boolean;
  /**
   * 可关闭，展示×，点击后关闭tag
   * @default false
   */
  closable?: boolean;
  /**
   * 设置tag的颜色风格
   * @default default
   */
  color?: string;
  /**
   * 设置点状动效
   * @default false
  */
  aniamation?: Boolean;
  /**
   *是否可以点击
   * @default false
  */
  checkable?: Boolean;
  /**
   * 是否被选中
   * @default true
   */
  checked?: Boolean
  /**
   * 设置标签type类型
   */
  type: null | 'border' | 'dot'
  /**
   * 标签名称
   */
  name?: String | Number
  /**
  * 不可用选，在checkable为true时生效
  */
  disabled?:Boolean
}>
