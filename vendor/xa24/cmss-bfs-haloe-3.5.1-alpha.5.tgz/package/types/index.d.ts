// import HaloE from './haloe';

// export default HaloE;
// export as namespace HaloE;
import type { App } from 'vue';
export * from './haloe.components';


interface HaloEGlobalOptions {
  size?: string;
  capture?: string| boolean;
  transfer?: boolean | string;
  select: {
    arrow: string;
    customArrow: string;
    arrowSize: number | string;
  };
  cell: {
    arrow: string;
    customArrow: string;
    arrowSize: number | string;
  };
  menu: {
    arrow: string;
    customArrow: string;
    arrowSize: number | string;
  };
  tree: {
    arrow: string;
    customArrow: string;
    arrowSize: number | string;
  };
  cascader: {
    arrow: string;
    customArrow: string;
    arrowSize: number | string;
    itemArrow: string;
    customItemArrow: string;
    itemArrowSize: number | string;
  };
  colorPicker: {
    arrow: string;
    customArrow: string;
    arrowSize: number | string;
  };
  datePicker: {
    icon: string;
    customIcon: string;
    iconSize: number | string;
  };
  timePicker: {
    icon: string;
    customIcon: string;
    iconSize: number | string;
  };
  tabs: {
    closeIcon: string;
    customCloseIcon: string;
    closeIconSize: number | string;
  };
  modal: {
    maskClosable: boolean | string;
  };
  image?: {
    toolbar: any[];
  };
}

interface HaloEInstallOptions extends HaloEGlobalOptions {
  locale?: any;
  i18n?: any;
}

declare module "@vue/runtime-core" {
  interface ComponentCustomProperties {
    $HaloE: HaloEGlobalOptions;
    $Spin: any;
    $Message: any;
    $Notice: any;
    $Modal: any;
    $Date: any;
    $Loading:any;
  }
}
declare const API: {
  version: string;
  locale: (l: any) => void;
  i18n: (fn: any) => void;
  install: (vue: App, opts?: HaloEInstallOptions) => void;
  lang: (code: string) => void;
};

export default API;
// export const install: (app: App, options?: HaloEInstallOptions) => void;