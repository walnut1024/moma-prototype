
import Vue, { VNode } from 'vue';
import type { DefineComponent } from 'vue';
export declare const Tooltip : DefineComponent<{
  /**
   * 提示内容
   */
  content?: string;
  /**
   * 提示使用浅色风格
   */
  light?: boolean;
  /**
   * 设置提示框宽度
   */
  // width?: number;
  /**
   * 设置tag的颜色风格
   * @default 'top-left'
   */
  // place?: string;
  /**
     * 提示框出现的位置，可选值为`top``top-start``top-end``bottom``bottom-start``bottom-end``left``left-start``left-end``right``right-start``right-end`，2.12.0 版本开始支持自动识别
  */
  placement?: 'top' | 'top-start' | 'top-end' | 'bottom' | 'bottom-start' | 'bottom-end' | 'left' | 'left-start' | 'left-end' | 'right' | 'right-start' | 'right-end';

  /**
     * 最大宽度，超出最大值后，文本将自动换行，并两端对齐
  */
  'max-width'?: string | number;

  /**
   * 是否禁用提示框
   */
  disabled?: boolean;
  /**
 * 延迟显示，单位毫秒
 */
  delay?: number;

  /**
   * 是否总是可见
   */
  always?: boolean;

  /**
   * 主题，可选值为 dark 或 light
   */
  theme?: string;

  /**
   * 出现位置的偏移量
   */
  offset?: number;

  /**
   * 是否将弹层放置于 body 内，在 Tabs、带有 fixed 的 Table 列内使用时，建议添加此属性，它将不受父级样式影响，从而达到更好的效果
   */
  transfer?: boolean;

  /**
   * 开启 transfer 时，给浮层添加额外的 class 名称
   */
  'transfer-class-name'?: string;

  /**
   * 是否显示 Tooltip 箭头
   */
  'visible-arrow'?: boolean;

  /**
   * 在提示框显示时触发
   */
  onOnPopperShow?: (event?: any) => any;

  /**
   * 在提示框消失时触发
   */
  onOnPopperHide?: (event?: any) => any;
}>
