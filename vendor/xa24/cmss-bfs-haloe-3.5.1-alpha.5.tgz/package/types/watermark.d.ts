import type { DefineComponent } from 'vue';

export declare const Watermark: DefineComponent<{
  /**
   * @description The z-index of the appended watermark element
   */
  zIndex: {
    type: Number,
    default: 9,
  },
  /**
   * @description The rotation angle of the watermark
   */
  rotate: {
    type: Number,
    default: -22,
  },
  /**
   * @description The width of the watermark
   */
  width: Number,
  /**
   * @description The height of the watermark
   */
  height: Number,
  /**
   * @description Image source, it is recommended to export 2x or 3x image, high priority (support base64 format)
   */
  image: String,
  /**
   * @description Watermark text content
   */
  content: {
    type: [String, Array<String>],
    default: '移动云',
  },
  /**
   * @description Text style
   */
  font: {
    // type: definePropType<WatermarkFontType>(Object),
    type: Object,
  },
  /**
   * @description The spacing between watermarks
   */
  gap: {
    type: Array<Number>,
    default: () => [100, 100],
  },
  /**
   * @description The offset of the watermark from the upper left corner of the container. The default is gap/2
   */
  offset: {
    type: Array<Number>,
  },
}>
