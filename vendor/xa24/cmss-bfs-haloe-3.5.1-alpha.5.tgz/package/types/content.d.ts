import type { DefineComponent } from 'vue';

export declare const Content: DefineComponent<{
}>
