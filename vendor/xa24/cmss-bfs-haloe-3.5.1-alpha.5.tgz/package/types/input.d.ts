import type { DefineComponent } from 'vue';

export declare const Input: DefineComponent<{
    /**
     * 指定选中项目的 value 值，可以使用 v-model 双向绑定数据。只接受 String 或 Number
     * @default ''
     */
    'model-value'?: String | Number;

    /**
     * 输入框类型，可选值为 text、textarea、password、url、email、date、number、tel
     * @default 'text'
     */
    type?: 'text' | 'textarea' | 'password' | 'url' | 'email' | 'date' | 'number' | 'tel';

    /**
     * 输入框尺寸，可选值为`large`、`middle`、`small`、`default`或者不填
     */
     size?: '' | 'large' | 'middle' | 'small' | 'default';

    /**
     * 输入框占位文本
     * @default ''
     */
    placeholder?: String;

    /**
     * 最大输入长度
     */
    maxlength?: String | Number;

    /**
     * 是否禁用
     * @default false
     */
    disabled?: Boolean;

    /**
     * 输入框尾部图标，仅在 text 类型下有效
     */
    icon?: String;

    /**
     * 自适应内容高度，仅在 textarea 类型下有效，可传入对象，如 { minRows: 2, maxRows: 6 }
     *  @default false
     */
    autosize?: Boolean | Object;

    /**
     * 文本域默认行数，仅在 textarea 类型下有效
     *  @default 2
     */
    rows?: Number;

    /**
     * 是否设置输入框为只读
     *  @default false
     */
    readonly?: Boolean;

    /**
     * 规定 <input> 元素的名称
     */
    name?: String;

    /**
     * 是否将用户的输入转换为 Number 类型
     *  @default false
     */
    number?: Boolean;

    /**
     * 是否自动获取焦点
     *  @default false
     */
    autofocus?: Boolean;

    /**
     * 是否对输入框内容进行拼写检查
     *  @default false
     */
    spellcheck?: Boolean;

    /**
     * 规定输入字段是否应该启用自动完成功能，如果不想让浏览器缓存input的值，设为'off'
     * @default 'off'
     */
    autocomplete?: String;
    
    /**
     * 是否显示清空按钮	
     *  @default false
     */
    clearable?: Boolean;

    /**
     * 给表单元素设置 id，详见 Form 用法
     */
    'element-id'?: String;

    /**
     * 规定当在表单中提交时，textarea中的文本如何换行。'soft'：textarea 中的文本不换行，'hard'：文本区域中的文本会包含换行符（如果有换行符）
     *  @default 'soft'
     */
    wrap?: 'hard' | 'soft';

    /**
     * 输入框头部图标
     * @default ''
     */
    prefix?: String;

    /**
     * 输入框尾部图标
     * @default ''
     */
    suffix?: String;
    
    /**
     * 是否显示为搜索型输入框	
     *  @default false
     */
    search?: Boolean;

    /**
     * 开启 search 时可用，是否有确认按钮，可设为按钮文字	
     *  @default false
     */
    'enter-button'?: Boolean | String;

    /**
     * 是否显示输入字数统计，可以配合 maxlength 使用
     *  @default false
     */
    'showWord-limit'?: Boolean;

    /**
     * 是否显示切换密码图标
     *  @default false
     */
    password?: Boolean;

    /**
     * 是否显示边框
     *  @default true
     */
    border?: Boolean;
    
    /**
     * 按下回车键时触发
     */
    'on-enter'?: (event?: any) => any;

    /**
     * 开启 search 时可用，点击搜索或按下回车键时触发
     */
    'on-search'?: (event?: any) => any;

    /**
     * 在用户按下任何键盘键（包括系统按钮，如箭头键和功能键）时发生，在手指放下至离开时，会一直调用
     */
    'on-keydown'?: (event?: any) => any;

    /**
     * 在用户按下并放开任何字母数字键时发生。系统按钮（例如，箭头键和功能键）无法得到识别，在手指放下至离开时，只调用一次
     */
    'on-keypress'?: (event?: any) => any;

    /**
     * 在用户放开任何先前按下的键盘键时发生。系统按钮（例如，箭头键和功能键）无法得到识别，在手指放下至离开时，只有离开的时候调用
     */
    'on-keyup'?: (event?: any) => any;

    /**
     * 设置 icon 属性后，点击图标时触发
     */
    'on-click'?: (event?: any) => any;

    /**
     * 输入框聚焦时触发
     */
    'on-focus'?: (event?: any) => any;

    /**
     * 输入框失去焦点时触发
     */
    'on-blur'?: (event?: any) => any;

    /**
     * 数据改变时触发
     */
    'on-change'?: (event?: any) => any;

    /**
     * 当输入框的值和上一次的值不同，并且输入框失去焦点时触发
     */
    'on-input-change'?: (event?: any) => any;

    /**
     * 开启 clearable 时可用，点击清空按钮时触发
     */
    'on-clear'?: (event?: any) => any;

    'v-slots'?: {
        /**
         * 前置内容，仅在 text 类型下有效
         */
        prepend?: () => any;

        /**
         * 后置内容，仅在 text 类型下有效
         */
        append?: () => any;

        /**
         * 输入框头部图标
         */
        prefix?: () => any;

        /**
         * 输入框尾部图标
         */
        suffix?: () => any;

    };
}>

export declare const InputGroup: DefineComponent<{
    /**
     * Input.Group 中所有的 Input 的大小，可选值为 `large`、`small`、`default` 或者不设置
     */
    size?: '' | 'large' | 'middle' | 'small' | 'default';
}>
