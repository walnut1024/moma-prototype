export declare class AutoComplete {
    /**
     * 输入框绑定的值，可使用 v-model 双向绑定
     */
    'model-value': string | number;

    /**
     * 显示下拉框默认选中的值
     */
    'selected-value': string | number;

    /**
     * 自动完成的数据源
     */
    data: [];

    /**
     * 是否可以清空选项
     */
    clearable: boolean;

    /**
     * 是否禁用
     */
    disabled: boolean;

    /**
     * 占位文本
     */
    placeholder: string;

    /**
     * 输入框尺寸，可选值为`large`、`middle`、`small`、`default`或者不填
     */
     size?: '' | 'large' | 'middle' | 'small' | 'default';

    /**
     * 输入框尾部图标
     */
    icon: string;

    /**
     * 是否根据输入项进行筛选。当其为一个函数时，会接收 `value` 和 `option` 两个参数，当 option 符合筛选条件时，应返回 true，反之则返回 false
     */
    'filter-method': Function | boolean;

    /**
     * 弹窗的展开方向，可选值为 `bottom`、`top`、`top-start`、`bottom-start`、`top-end`、`bottom-end`，2.12.0 版本开始支持自动识别
     */
    placement: string;

    /**
     * 是否将弹层放置于 body 内，在 Tabs、带有 fixed 的 Table 列内使用时，建议添加此属性，它将不受父级样式影响，从而达到更好的效果
     */
    transfer: boolean;

    /**
     * 给表单元素设置 `id`，详见 Form 用法。
     */
    'element-id': string;

    /**
     * 开启 transfer 时，给浮层添加额外的 class 名称
     */
    'transfer-class-name': string;

    /**
     * 是否开启 capture 模式，也可通过全局配置
     */
    capture: boolean;

    /**
     * 是否开启 Popper 的 eventsEnabled 属性，开启可能会牺牲一定的性能
     */
    'events-enabled': boolean;

    /**
     * 是否高亮匹配到的关键词
     * @default false
     */
    highlight: boolean;

    /**
     * 是否对高亮匹配到的关键词中的英文字母忽略大小写，仅在highlight为true时生效
     * @default true
     */
    'ignore-case': boolean;

    /**
     * 是否使用懒加载
     * @default false
     */
    'enabled-lazy-load': boolean;

    /**
     * 是否在加载中
     * @default false
     */
    loading: boolean;

    /**
     * 是否懒加载失败
     * @default false
     */
    'is-error': string;

    /**
     * 懒加载失败的提示文案
     * @default '请求失败，点击重新加载'
     */
    'error-text': string;

    /**
     * 是否懒加载结束
     * @default false
     */
    'is-finished': string;

    /**
     * 懒加载结束的提示文案
     * @default '没有更多了'
     */
    'finished-text': string;

    /**
     * 选中 option，或 input 的 value 变化时，调用此函数
     */
    $emit(eventName: 'on-change'): this;

    /**
     * 被选中时调用，参数为选中项的 value 值
     */
    $emit(eventName: 'on-select'): this;

    /**
     * 搜索补全项的时候调用
     */
    $emit(eventName: 'on-search'): this;

    /**
     * 懒加载滚动条滚动到底部，且is-finished为false时触发
     */
    $emit(eventName: 'on-load-more'): this;

    /**
     * 聚焦时触发
     */
    $emit(eventName: 'on-focus'): this;

    /**
     * 失焦时触发
     */
    $emit(eventName: 'on-blur'): this;

    /**
     * 清空时触发
     */
    $emit(eventName: 'on-clear'): this;
}
