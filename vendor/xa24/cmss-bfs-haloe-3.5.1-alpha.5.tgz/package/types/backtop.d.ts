
import type { DefineComponent } from 'vue';
export declare const Backtop: DefineComponent<{
  /**
   * @description the button will not show until the scroll height reaches this value.
   * default 200
   */
  visibilityHeight?:Number ;
  /**
   * @description the target to trigger scroll.
   * default: ''
   */
  target?: String;
  /**
   * @description right distance.
   * default:40
   */
  right?:Number;
  /**
   * @description bottom distance.
   * default:40
   */
  bottom?:Number;

  /**
   * 按下backtop触发 
   */ 
  $emit(eventName: 'click'): ()=>any;
}>