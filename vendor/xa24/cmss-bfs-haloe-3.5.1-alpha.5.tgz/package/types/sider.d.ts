import Vue, { VNode } from 'vue';
import type { DefineComponent } from 'vue';
export declare const Sider : DefineComponent<{
}>
