import type { DefineComponent } from 'vue';

export declare const Affix: DefineComponent<{
    /**
     * affix zIndex value
     * default 100
     */
    zIndex?: number;

    /**
     *  target container. (CSS selector)
     * default :''
     */
    target?: string;

    /**
     * offset distance
     * default:0
     */
    offset?: Number;

    /**
     * position of affix
     * default "top"
     */
    position?: 'top'|'bottom';

    /**
     * 页面滚动时触发
     */
    scroll?: (value: { scrollTop: number, fixed: boolean }) => void;

    /**
     * 元素fixed值改变时触发
     */
    change?:(fixed: boolean) => void;

    'v-slots'?: {
        /**
         *默认插槽
         */
        default?: () => any;
    };
}>