import Vue, { VNode } from 'vue'
import type { DefineComponent } from 'vue';
export declare const Search : DefineComponent<{
  /**
   * icon展开输入式搜索样式，默认是按钮搜索样式
   * @default false
   */
  'is-icon': boolean

  /**
   * 回车键搜索样式，默认是按钮搜索样式
   * @default false
   */
  'is-enter': boolean

  /**
   * 搜索框尺寸，可选值为 small、middle、large 或者不设置
   */
  size?: 'small' | 'middle' | 'large'

  /**
   * 默认文字
   * @default '''
   */
  placeholder: string

  /**
   * 筛选条件的选项，传入此值启用筛选搜索样式
   * @default null
   */
  'filter-items': []

  /**
   * 筛选条件默认值
   * @default null
   */
  'filter-value': any

  /**
   * 是否支持搜索
   * @default false
   */
  filterable: boolean

  /**
   * 筛选条件选择器的宽度
   * @default 110
   */
  'filter-width': string | number

  /**
   * 前置标签内容
   * @default '''
   */
  'prepend-label': string

  /**
   * 是否显示清空按钮
   * @default true
   */
  clearable: boolean

  /**
   * 点击搜索图标或按下回车触发
   */
  $emit(eventName: 'on-submit'): ()=>any

  /**
   * 筛选条件输入框切换时触发
   */
  $emit(eventName: 'on-select'): ()=>any
}>
