import type { DefineComponent } from "vue";
export type componentSizes = ["", "default", "small", "large"];
export declare const Space: DefineComponent<{
  /**
   * @description Placement direction
   */
  direction: {
    type: String;
    values: ["horizontal", "vertical"];
    default: "horizontal";
  };
  /**
   * @description Classname
   */
  class: {
    type: [String, Object, Array<any>];
    default: "";
  };
  /**
   * @description Extra style rules
   */
  style: {
    type: [String, Array<any>, Object];
    default: "";
  };
  /**
   * @description Controls the alignment of items
   *  "-moz-initial" | "inherit" | "initial" | "revert" | "unset"、"center" | "end" | "flex-end" | "flex-start" | "self-end" | "self-start" | "start"、"auto" | "baseline" | "normal" | "stretch"
   */
  alignment: {
    type: String;
    default: "center";
  };
  /**
   * @description Prefix for space-items
   */
  prefixCls: {
    type: String;
  };
  /**
   * @description Spacer
   */
  spacer: {
    type: [Object, String, Number, Array<any>];
    default: null;
  };
  /**
   * @description Auto wrapping
   */
  wrap: Boolean;
  /**
   * @description Whether to fill the container
   */
  fill: Boolean;
  /**
   * @description Ratio of fill
   */
  fillRatio: {
    type: Number;
    default: 100;
  };
  /**
   * @description Spacing size
   */
  size: {
    type: [String, Array<Number>, Number];
    values: componentSizes;
    // validator: (val)=> {
    //   return (
    //     isNumber(val) ||
    //     (isArray(val) && val.length === 2 && val.every(isNumber))
    //   )
    // },
  };
  "v-slots"?: {
    /**
     * 自定义 Spin 的内容，设置slot后，默认的样式不生效
     */
    default?: () => any;
  };
}>;
