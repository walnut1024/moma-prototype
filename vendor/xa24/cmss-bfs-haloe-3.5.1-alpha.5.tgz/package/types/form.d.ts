import type { DefineComponent } from 'vue';

export declare const Form: DefineComponent<{
}>
