// Type definitions for iview 3.3.1
// Project: https://github.com/iview/iview
// Definitions by: yangdan
// Definitions: https://github.com/yangdan8/iview.git
import type { DefineComponent } from 'vue';

export declare const Header: DefineComponent<{
}>