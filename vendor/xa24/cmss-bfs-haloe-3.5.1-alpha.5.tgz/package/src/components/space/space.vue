<template>
  <div>This is Space</div>
</template>

<script setup>
defineOptions({
  name: 'Space'
})
</script>
