/*
 * @Description: Stay hungry，Stay foolish
 * @Author: ''
 * @Date: 2023-10-22 19:27:54
 * @LastEditTime: 2023-10-22 19:31:41
 * @LastEditors: ''
 */
import { computed, defineComponent, h, renderSlot } from 'vue'

const SpaceItem=defineComponent({
  name:"ESpaceItem",

  props:{
    prefixCls: {
      type: String,
    },
  },
  setup(props,{slots}){
    const classes = computed(() => `${props.prefixCls || 'haloe-space'}-item`)

    return ()=>h('div',{class:classes.value},renderSlot(slots,'default'))
  }
})

export default SpaceItem