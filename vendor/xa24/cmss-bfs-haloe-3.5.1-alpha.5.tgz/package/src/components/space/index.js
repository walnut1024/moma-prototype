/*
 * @Description: Stay hungry，Stay foolish
 * @Author: ''
 * @Date: 2023-10-22 19:27:04
 * @LastEditTime: 2023-10-22 20:06:22
 * @LastEditors: ''
 */
import Space from './space.js';

export default Space;
