/*
 * @Description: Stay hungry，Stay foolish
 * @Author: ''
 * @Date: 2023-10-22 19:33:49
 * @LastEditTime: 2023-10-22 19:39:18
 * @LastEditors: ''
 */
import {Comment,isVNode,Fragment} from "vue"

export const PatchFlags= {
  TEXT : 1,
  CLASS : 2,
  STYLE : 4,
  PROPS : 8,
  FULL_PROPS : 16,
  HYDRATE_EVENTS : 32,
  STABLE_FRAGMENT : 64,
  KEYED_FRAGMENT : 128,
  UNKEYED_FRAGMENT :256,
  NEED_PATCH :512,
  DYNAMIC_SLOTS : 1024,
  HOISTED : -1,
  BAIL : -2,
}

export const isNumber = (val)=> typeof val === 'number'

export function isFragment(node) {
  return isVNode(node) && node.type === Fragment
}

export function isComment(node) {
  return isVNode(node) && node.type === Comment
}

export function isValidElementNode(node) {
  return isVNode(node) && !isFragment(node) && !isComment(node)
}

export const componentSizes = ['', 'default', 'small', 'large']