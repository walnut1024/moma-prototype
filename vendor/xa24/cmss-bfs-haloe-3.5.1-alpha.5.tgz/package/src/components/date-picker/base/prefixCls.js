export default 'haloe-date-picker-cells'
