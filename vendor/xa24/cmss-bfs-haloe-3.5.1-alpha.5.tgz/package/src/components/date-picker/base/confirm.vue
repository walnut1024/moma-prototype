<template>
  <div :class="[prefixCls + '-confirm']" @keydown.tab.capture="handleTab">
    <i-button
      :class="timeClasses"
      size="small"
      type="text"
      :disabled="timeDisabled"
      v-if="showTime"
      @click="handleToggleTime"
    >
      {{ labels.time }}
    </i-button>
    <i-button
      v-if="presently"
      type="text"
      size="small"
      @click="handleJustNow"
      @keydown.enter="handleJustNow"
    >
      {{ labels.justNow }}
    </i-button>
    <i-button
      v-if="isShowCancel"
      size="small"
      class="haloe-picker-confirm-btn-cancel"
      @click="handleClear"
      @keydown.enter="handleClear"
    >
      {{ labels.clear }}
    </i-button>
    <i-button
      size="small"
      type="primary"
      @click="handleSuccess"
      @keydown.enter="handleSuccess"
    >
      {{ labels.ok }}
    </i-button>
  </div>
</template>
<script>
import iButton from '../../button/button.vue'
import Locale from '../../../mixins/locale'
import { isClient } from '../../../utils/index'

const prefixCls = 'haloe-picker'

export default {
  mixins: [Locale],
  components: { iButton },
  emits: ['on-pick-clear', 'on-pick-success', 'on-pick-toggle-time','on-pick-just-now'],
  inject: ['PickerInstance'],
  props: {
    showTime: {
      type: Boolean,
      default: false,
    },
    isTime: {
      type: Boolean,
      default: false,
    },
    timeDisabled: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      prefixCls: prefixCls,
    }
  },
  computed: {
    timeClasses() {
      return `${prefixCls}-confirm-time`
    },
    labels() {
      const labels = ['time', 'clear', 'ok','justNow']
      const values = [this.isTime ? 'selectDate' : 'selectTime', 'clear', 'ok','justNow']
      return labels.reduce((obj, key, i) => {
        obj[key] = this.t('i.datepicker.' + values[i])
        return obj
      }, {})
    },
    presently () {
      return this.PickerInstance&&this.PickerInstance.presently?true:false
    },
    isShowCancel(){
      return this.PickerInstance&&this.PickerInstance.isShowCancel?true:false
    }
  },
  methods: {
    handleClear() {
      this.$emit('on-pick-clear')
    },
    handleSuccess() {
      this.$emit('on-pick-success')
    },
    handleJustNow(){
      this.$emit('on-pick-just-now')
    },
    handleToggleTime() {
      if (this.timeDisabled) return
      this.$emit('on-pick-toggle-time')
      this.PickerInstance.handleOnFocusInput()
      this.PickerInstance.handleOnUpdatePopper()
    },
    handleTab(e) {
      const tabbables = [...this.$el.children]
      const expectedFocus = tabbables[e.shiftKey ? 'shift' : 'pop']()

      if (isClient && document.activeElement === expectedFocus) {
        e.preventDefault()
        e.stopPropagation()
        this.PickerInstance.handleOnFocusInput()
      }
    },
  },
}
</script>
