import { clearHours } from '../util'
import random from '../../../utils/random_str'

export default {
  name: 'PanelTable',
  emits: ['on-pick', 'on-pick-click', 'on-change-range'],
  inject: ['PickerInstance'],
  props: {
    tableDate: {
      type: Date,
      required: true,
    },
    disabledDate: {
      type: Function,
    },
    selectionMode: {
      type: String,
      required: true,
    },
    modelValue: {
      type: Array,
      required: true,
    },
    rangeState: {
      type: Object,
      default: () => ({
        from: null,
        to: null,
        selecting: false,
      }),
    },
    focusedDate: {
      type: Date,
      required: true,
    },
  },
  data() {
    return {
      id: random(6),
      weekIndex: 0,
    }
  },
  computed: {
    dates() {
      const { selectionMode, modelValue, rangeState } = this
      const rangeSelecting = selectionMode === 'range' && rangeState.selecting
      return rangeSelecting ? [rangeState.from] : modelValue
    },
  },
  methods: {
    handleClick(cell, e) {
      e.stopPropagation()
      const week = cell.week
      for(let i = 0; i < this.cells.length; i++){
        if(this.cells[i].week === week && this.cells[i].type === 'weekLabel'){
          if(cell.type === 'nextMonth'){
            if(this.cells[39].type != 'nextMonth' && cell.index > 48){
              this.weekIndex = this.cells[i].index - 40
            }else if(this.cells[39].type === 'nextMonth' && cell.index > 48){
              this.weekIndex = this.cells[i].index - 32
            }else{
              this.weekIndex = this.cells[i].index - 32
            }
          }else if(cell.type === 'prevMonth'){
            this.weekIndex = this.cells[i].index + 32
          }else{
            this.weekIndex = this.cells[i].index
          }
          break
        }
      }
      if (cell.disabled || cell.type === 'weekLabel') return
      const newDate = new Date(clearHours(cell.date))

      this.$emit('on-pick', newDate, cell.year, cell.week)
      this.$emit('on-pick-click')
    },
    handleMouseMove(cell) {
      if (!this.rangeState.selecting) return
      if (cell.disabled) return
      const newDate = cell.date
      this.$emit('on-change-range', newDate)
    },
    addPanelTable() {
      const root = this.PickerInstance
      if (!root.panelTableList) root.panelTableList = []
      root.panelTableList.push({
        id: this.id,
        panelTable: this,
      })
    },
    removePanelTable() {
      const root = this.PickerInstance
      if (root.panelTableList && root.panelTableList.length) {
        const index = root.panelTableList.findIndex(
          (item) => item.id === this.id
        )
        root.panelTableList.splice(index, 1)
      }
    },
  },
  mounted() {
    this.addPanelTable()
  },
  beforeUnmount() {
    this.removePanelTable()
  },
}
