<template>
  <div :class="classes" @mousedown.prevent>
    <div :class="[prefixCls + '-body']">
      <div :class="[prefixCls + '-content', prefixCls + '-content-left']">
        <div :class="[timePrefixCls + '-header']">
          <template v-if="showDate">{{ leftDatePanelLabel }}</template>
          <template v-else>{{ t('i.datepicker.startTime') }}</template>
        </div>
        <time-spinner
          ref="timeSpinner"
          :steps="steps"
          :timeStyle="timeStyle[0]"
          :show-seconds="showSeconds"
          :hours="modelValue[0] && dateStart.getHours()"
          :minutes="modelValue[0] && dateStart.getMinutes()"
          :seconds="modelValue[0] && dateStart.getSeconds()"
          :duodecimal="duodecimal"
          :disabled-hours="disabledHours"
          :disabled-minutes="disabledMinutes"
          :disabled-seconds="disabledSeconds"
          :hide-disabled-options="hideDisabledOptions"
          @on-style-change="handleStyleStartChange"
          @on-change="handleStartChange"
          @on-pick-click="handlePickClick"
        ></time-spinner>
      </div>
      <div :class="[prefixCls + '-content', prefixCls + '-content-right']">
        <div :class="[timePrefixCls + '-header']">
          <template v-if="showDate">{{ rightDatePanelLabel }}</template>
          <template v-else>{{ t('i.datepicker.endTime') }}</template>
        </div>
        <time-spinner
          ref="timeSpinnerEnd"
          :steps="steps"
          :timeStyle="timeStyle[1]"
          :show-seconds="showSeconds"
          :hours="modelValue[1] && dateEnd.getHours()"
          :minutes="modelValue[1] && dateEnd.getMinutes()"
          :seconds="modelValue[1] && dateEnd.getSeconds()"
          :duodecimal="duodecimal"
          :disabled-hours="disabledHours"
          :disabled-minutes="disabledMinutes"
          :disabled-seconds="disabledSeconds"
          :hide-disabled-options="hideDisabledOptions"
          @on-style-change="handleStyleEndChange"
          @on-change="handleEndChange"
          @on-pick-click="handlePickClick"
        ></time-spinner>
      </div>
      <Confirm
        v-if="confirm"
        @on-pick-clear="handlePickClear"
        @on-pick-success="handlePickSuccess"
        @on-pick-just-now="handlePickJustNow"
      ></Confirm>
    </div>
  </div>
</template>
<script>
import TimeSpinner from '../../base/time-spinner.vue'
import Confirm from '../../base/confirm.vue'
import Options from '../../time-mixins'

import Mixin from '../panel-mixin'
import Locale from '../../../../mixins/locale'

import { initTimeDate, formatDateLabels } from '../../util'

const prefixCls = 'haloe-picker-panel'
// const timePrefixCls = 'haloe-time-spinner'
const timePrefixCls = 'haloe-time-picker'
const capitalize = (str) => str[0].toUpperCase() + str.slice(1)

export default {
  name: 'RangeTimePickerPanel',
  mixins: [Mixin, Locale, Options],
  components: { TimeSpinner, Confirm },
  emits: ['on-pick', 'on-style'],
  props: {
    steps: {
      type: Array,
      default: () => [],
    },
    format: {
      type: String,
      default: 'HH:mm:ss',
    },
    modelValue: {
      type: Array,
      required: true,
    },
    duodecimal: {
      type: Boolean,
      default: false,
    },
    timeStyle: {
      type: Array,
      default() {
        return []
      },
    }
  },
  data() {
    const [dateStart, dateEnd] = this.modelValue.slice()
    return {
      prefixCls: prefixCls,
      timePrefixCls: timePrefixCls,
      showDate: false,
      dateStart: dateStart || initTimeDate(),
      dateEnd: dateEnd || initTimeDate(),
    }
  },
  computed: {
    classes() {
      return [
        `${prefixCls}-body-wrapper`,
        `${timePrefixCls}-with-range`,
        {
          [`${timePrefixCls}-with-seconds`]: this.showSeconds,
        },
      ]
    },
    showSeconds() {
      //fix Hour & Minute Picker bug,show seconds when has "ss"
      return !!(this.format || '').match(/ss/)
    },
    leftDatePanelLabel() {
      return this.panelLabelConfig(this.date)
    },
    rightDatePanelLabel() {
      return this.panelLabelConfig(this.dateEnd)
    },
  },
  watch: {
    modelValue(dates) {
      const [dateStart, dateEnd] = dates.slice()
      this.dateStart = dateStart || initTimeDate()
      this.dateEnd = dateEnd || initTimeDate()
    },
  },
  methods: {
    handleStyleStartChange (date) {
      let style = [date, this.timeStyle[1]]
      this.$emit('on-style', style)
    },
    handleStyleEndChange (date) {
      let style = [this.timeStyle[0], date]
      this.$emit('on-style', style)
    },
    panelLabelConfig(date) {
      const locale = this.t('i.locale')
      const datePanelLabel = this.t('i.datepicker.datePanelLabel')
      const { labels, separator } = formatDateLabels(
        locale,
        datePanelLabel,
        date || initTimeDate()
      )
      return [labels[0].label, separator, labels[1].label].join('')
    },
    handleChange(start, end, emit = true) {
      const dateStart = new Date(this.dateStart)
      let dateEnd = new Date(this.dateEnd)

      // set dateStart
      Object.keys(start).forEach((type) => {
        dateStart[`set${capitalize(type)}`](start[type])
      })

      // set dateEnd
      Object.keys(end).forEach((type) => {
        dateEnd[`set${capitalize(type)}`](end[type])
      })

      // judge endTime > startTime?
      if (dateEnd < dateStart) dateEnd = dateStart

      if (emit) this.$emit('on-pick', [dateStart, dateEnd], 'time')
    },
    handleStartChange(date) {
      this.handleChange(date, {})
    },
    handleEndChange(date) {
      this.handleChange({}, date)
    },
    updateScroll() {
      this.$refs.timeSpinner.updateScroll()
      this.$refs.timeSpinnerEnd.updateScroll()
    },
  },
  mounted() {
    if (this.$parent && this.$parent.$options.name === 'DatePicker')
      this.showDate = true
  },
}
</script>
