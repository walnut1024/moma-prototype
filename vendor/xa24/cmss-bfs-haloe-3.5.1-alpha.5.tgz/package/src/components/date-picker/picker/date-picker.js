import Picker from '../picker.vue'
import DatePickerPanel from '../panel/Date/date.vue'
import RangeDatePickerPanel from '../panel/Date/date-range.vue'

import { oneOf } from '../../../utils/assist'

export default {
  name: 'CalendarPicker',
  mixins: [Picker],
  data() {
    const week = ''
    const year = ''
    return {
      week,
      year
    }
  },
  props: {
    type: {
      validator(value) {
        return oneOf(value, [
          'year',
          'month',
          'dateweek',
          'date',
          'daterange',
          'datetime',
          'datetimerange',
        ])
      },
      default: 'date',
    },
  },
  components: { DatePickerPanel, RangeDatePickerPanel },
  computed: {
    panel() {
      const isRange = this.type === 'daterange' || this.type === 'datetimerange'
      return isRange ? 'RangeDatePickerPanel' : 'DatePickerPanel'
    },
    ownPickerProps() {
      return this.options
    },
  },
}
