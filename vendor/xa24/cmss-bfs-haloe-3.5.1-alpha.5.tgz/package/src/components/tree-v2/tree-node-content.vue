<!--
 * @Description: Stay hungry，Stay foolish
 * @Author: ''
 * @Date: 2023-09-19 22:28:53
 * @LastEditTime: 2023-09-20 10:13:13
 * @LastEditors: ''
-->
<script>
// @ts-nocheck
import { defineComponent, h, inject } from 'vue'

export default defineComponent({
  name: 'ETreeNodeContent',
  props: {
    node: {
      type: Object,
      required: true,
    },
    renderContent: Function,
  },
  setup(props) {
    const nodeInstance = inject('NodeInstance')
    const tree = inject('RootTree')
    return () => {
      const node = props.node
      const { data, store } = node
      return props.renderContent
        ? props.renderContent(h, { _self: nodeInstance, node, data, store })
        : tree.ctx.slots.default
          ? tree.ctx.slots.default({ node, data })
          : h('span', { class: 'haloe-tree-node__label' }, [node.label])
    }
  },
})
</script>
