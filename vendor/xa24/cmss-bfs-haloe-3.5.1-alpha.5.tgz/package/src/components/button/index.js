/*
 * @Description: Stay hungry，Stay foolish
 * @Author: ''
 * @Date: 2023-06-09 08:38:08
 * @LastEditTime: 2023-10-11 22:32:25
 * @LastEditors: ''
 */
import Button from './button.vue';

import ButtonGroup from '../button-group';
Button.install = function (app) {
  app.component('e'+Button.name, Button);
  app.component('e'+ButtonGroup.name, ButtonGroup);
  return app;
};
export default Button;
