
import {describe,test,expect} from "vitest"
import {mount} from "@vue/test-utils"

import {h} from "vue"

import Page from "../page.vue"

describe("Page.vue",()=>{
  test("test current",()=>{

    const wrapper=mount(()=>h(Page,{current:3}))

    wrapper.find(".haloe-page__list")
    expect(wrapper.find(".haloe-page-item-active").attributes("title")).toBe("3")
  })

  test("test total",()=>{
    const wrapper=mount(Page,{
      props:{
        total:100,
        current:3
      },
      
    })
    expect(wrapper.find(".haloe-page__title").text()).toContain("100")
  })

  test("test page-size",()=>{
    const wrapper = mount(Page,{
      props:{
        total:100,
        current:3,
        pageSize:20,
        showSizer:true
      }
    })

    expect(wrapper.find(".haloe-select-dropdown").exists()).toBe(true)
  })

  test("test showElevator",()=>{
    const wrapper=mount(Page,{
      props:{
        showElevator:true,
        total:100
      }
    })

    expect(wrapper.find(".haloe-page__jump").exists()).toBe(true)
  })

  test("test showTotal",()=>{
    const wrapper=mount(Page,{
      props:{
        total:200,
        showTotal:false
      }
    })

    expect(wrapper.find(".haloe-page__title").exists()).toBe(false)
  })

  test("test simple",()=>{
    const wrapper=mount(Page,{
      props:{
        simple:true
      }
    })

    expect(wrapper.find(".haloe-page-simple").exists()).toBe(true)
  })

  test("test prev&next click",async()=>{
    const wrapper=mount(Page,{
      props:{
        current:3,
        total:100
      }
    })

    const prev=wrapper.find(".haloe-page-prev")
    await prev.trigger("click")
    expect(wrapper.find(".haloe-page-item-active").attributes("title")).toContain("2")

    
    const next=wrapper.find(".haloe-page-next")
    await next.trigger('click')
    await next.trigger('click')
    expect(wrapper.find(".haloe-page-item-active").attributes("title")).toContain("4")

    expect(wrapper.emitted()).toHaveProperty("on-prev")
    expect(wrapper.emitted()).toHaveProperty("on-next")
    expect(wrapper.emitted()).toHaveProperty("on-change")

  })
})