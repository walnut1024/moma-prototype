// import Carousel from './carousel.vue';
import CarouselItem from './carousel-item.vue';

import Carousel from './carousel-v2.vue';
// Carousel.Item = CarouselItem;
export default Carousel;