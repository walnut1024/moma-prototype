<template>
  <div
    :class="[...classes, ...cascaderClasses]"
    v-click-outside:[capture]="handleClose"
    v-click-outside:[capture].mousedown="onClickOutside"
    v-click-outside:[capture].touchstart="onClickOutside"
  >
    <div
      ref="reference"
      :class="selectionCls"
      :tabindex="selectTabindex"
      @blur="toggleHeaderFocus"
      @focus="toggleHeaderFocus"
      @click="toggleMenu"
      @keydown.esc="handleKeydown"
      @keydown.enter="handleKeydown"
      @keydown.up.prevent="handleKeydown"
      @keydown.down.prevent="handleKeydown"
      @keydown.tab="handleKeydown"
      @keydown.delete="handleKeydown"
      @mouseenter="hasMouseHoverHead = true"
      @mouseleave="hasMouseHoverHead = false"
    >
      <slot name="input">
        <input type="hidden" :name="name" :value="values" />
        <!-- in mulcasecader: {{ values }} -->
        <select-head
          :max-tag-count="maxTagCount"
          ref="selectHead"
          :filterable="filterable"
          :multiple="multiple"
          :values="values"
          :clearable="canBeCleared"
          :prefix="prefix"
          :disabled="itemDisabled"
          :remote="remote"
          :input-element-id="elementId"
          :initial-label="initialLabel"
          :placeholder="placeholder"
          :query-prop="query"
          :limited="limited"
          :max-tag-placeholder="maxTagPlaceholder"
          :allow-create="allowCreate"
          :show-create-item="showCreateItem"
          :colorTag="colorTag"
          @on-query-change="onQueryChange"
          @on-input-focus="isFocused = true"
          @on-input-blur="isFocused = false"
          @on-clear="clearSingleSelect"
          @on-enter="handleCreateItem"
        >
          <slot name="prefix"></slot>
          <span v-if="isLimited">{{ value.length }}/{{ limited }}</span>
        </select-head>
      </slot>
    </div>
    <!-- <transition name="transition-drop"> -->
    <Drop
      ref="dropdown"
      :classes="[dropdownCls, casecaderDropdownCls]"
      :visible="dropVisible"
      :placement="placement"
      :eventsEnabled="eventsEnabled"
      :transfer="transfer"
      transition-name="transition-drop"
    >
      <Caspanel
        v-show="!filterable || (filterable && this.query === '')"
        ref="caspanel"
        :prefix-cls="prefixCls"
        :check-strictly="checkStrictly"
        :options="displayOptions"
        :trigger="trigger"
        @on-change="onChange"
        :disabled="itemDisabled"
      />
      <div
        :class="['haloe-cascader' + '-dropdown']"
        v-show="filterable && query !== '' && querySelections.length"
      >
        <ul :class="[prefixCls + '-dropdown-list']">
          <li
            :class="[
              prefixCls + '-item',
              {
                [prefixCls + '-item-disabled']: item.disabled,
              },
            ]"
            v-for="(item, index) in querySelections"
            :key="index"
            @click="handleSelectItem(index)"
            v-html="item.display"
          ></li>
        </ul>
      </div>
      <ul
        v-show="
          (filterable && query !== '' && !querySelections.length)||!displayOptions.length
        "
        :class="['haloe-cascader' + '-not-found-tip']"
      >
        <li>{{ localeNotFoundText }}</li>
      </ul>
    </Drop>
    <!-- </transition> -->
  </div>
</template>
<script>
import {
  computed,
  defineComponent,
  getCurrentInstance,
  reactive,
  ref,
  nextTick,
  watch,
  onMounted,
  provide,
  onBeforeUnmount,
  withModifiers,
  resolveComponent,
} from 'vue'
import Select from '../select/select.vue'
import { cloneDeep } from 'lodash'
import Caspanel from './Caspanel.vue'
import Drop from '../select/dropdown.vue'
import { oneOf } from '../../utils/assist'
import mixinsForm from "../../mixins/form"
import globalConfig from '../../mixins/globalConfig'
const prefixCls = 'haloe-cascader'
const selectPrefixCls = 'haloe-select'

export default defineComponent({
  extends: Select,
  // eslint-disable-next-line
  name: 'iSelect',
  mixins: [ mixinsForm, globalConfig],
  components: {
    Caspanel,
    Drop,
  },
  emits: ['on-change','on-change-object', 'update:modelValue'],
  props: {
    modelValue: {
      type: Array,
      default() {
        return []
      },
    },
    notFoundText: {
      type: String,
    },
    multiple: {
      type: Boolean,
      default: true,
    },
    options: {
      type: Array,
      default: () => [],
    },
    splitor: {
      type: String,
      default: '/',
    },
    checkStrictly: {
      type: Boolean,
      default: true,
    },
    trigger: {
      validator(value) {
        return oneOf(value, ['click', 'hover'])
      },
      default: 'click',
    },
    showCheckedStrategy: {
      validator(value) {
        return oneOf(value, ['SHOW_CHILD', 'SHOW_ALL', 'SHOW_PARENT'])
      },
      default: 'SHOW_CHILD',
    },
    colorTag:{
      type:String,
      default:"default"
    }
    /**
     * [
     *   [
     *     { label, value, checked }, {label, value, checked}, {label, value, checked}
     *   ],
     *   [
     *     { label, value, checked }, {label, value, checked}, {label, value, checked}
     *   ]
     * ]
     */
  },
  setup() {
    /* const displayOptions = computed(() => {
      const ret = this.initOptions()
      nextTick(() => {
        ;(this.value || []).forEach((value) => this.selectTag({ value }))
      })
      return ret
    })
    return {
      displayOptions,
    } */
  },
  data() {
    const ret = this.initOptions()
    // console.log(ret, "display: ", ret[0].children[0].parent === ret[0])
    /* return {
      displayOptions: ret,
    } */
    return {
      query: '',
      displayOptions: ret,
      disabledLazyUpdateValue: true,
    }
  },
  computed: {
    /* displayOptions() {
      console.log('display options')
      // TODO: 拷贝值
      const ret = this.initOptions()
      this.$nextTick(() => {
        ;(this.modelValue || []).forEach((value) => this.selectTag({ value }))
      })
      return ret
    }, */
    canBeCleared() {
      // console.log('can be cleared')
      // const uiStateMatch = this.hasMouseHoverHead || this.active
      const uiStateMatch = this.hasMouseHoverHead
      const qualifiesForClear = !this.itemDisabled && this.clearable
      return uiStateMatch && qualifiesForClear && this.reset // we return a function
    },
    casecaderDropdownCls() {
      return {
        [prefixCls + '-transfer']: this.transfer,
        [this.transferClassName]: this.transferClassName,
      }
    },
    showCloseIcon() {
      return (
        this.values &&
        this.values.length &&
        this.clearable &&
        !this.itemDisabled
      )
    },
    cascaderClasses() {
      return [
        `${prefixCls}`,
        {
          [`${prefixCls}-show-clear`]: this.showCloseIcon,
          [`${prefixCls}-size-${this.size}`]: !!this.size,
          [`${prefixCls}-visible`]: this.visible,
          [`${prefixCls}-disabled`]: this.itemDisabled,
          [`${prefixCls}-not-found`]:
            this.filterable &&
            this.query !== '' &&
            !this.querySelections.length,
        },
      ]
    },
    querySelections() {
      let selections = []
      function getSelections(arr, label, value) {
        const cloneArr = cloneDeep(arr)
        for (let i = 0; i < cloneArr.length; i++) {
          let item = cloneArr[i]
          item.__label = label ? label + '/' + item.label : item.label
          item.__value = value ? value + ',' + item.value : item.value

          if (item.children && item.children.length) {
            getSelections(item.children, item.__label, item.__value)
            delete item.__label
            delete item.__value
          } else {
            selections.push({
              label: item.__label,
              value: item.__value,
              display: item.__label,
              item: item,
              disabled: !!item.disabled,
            })
          }
        }
      }
      getSelections(this.displayOptions)

      selections = selections
        .filter((item) => {
          return item.label ? item.label.indexOf(this.query) > -1 : false
        })
        .map((item) => {
          item.display = item.display.replace(
            new RegExp(this.query, 'g'),
            `<span>${this.query}</span>`
          )
          return item
        })
      return selections
    },
  },
  watch: {
    modelValue: {
      handler: function (val) {
        // console.log('value change', val)
        // 不一样才要变
        if (
          this.values.length !== val.length ||
          (val || []).find((v) => !this.values.find((item) => item.value === v))
        ) {
          // this.$nextTick(() => {
          // console.log('in modelValue')
          this.initOptions()
          return (val || []).forEach((value) => this.selectTag({ value }))
          // })
        }
      },
      immediate: true,
    },
    values() {
      // console.log('values change', this.values, Date.now())
      this.$emit(
        'update:modelValue',
        this.values.map(({ value }) => value)
      )
    },
  },
  provide: function () {
    return {
      onRemoveTag: this.removeTag,
    }
  },
  methods: {
    handleClose() {
      this.visible = false
    },

    handleInput(event){
      this.query = event.target.value
    },

    handleSelectItem(index) {
      const item = this.querySelections[index]
      if (item.item.disabled) return false
      let itemArr = item.value.split(',')

      // 遍历
      function treeForeach (item, tree, func) {
        tree.forEach(data => {
          func(data)
          data.children && treeForeach(item, data.children, func) // 遍历子树
        })
      }
      // todo: 改变“搜索选中的node节点”的checked状态
      treeForeach(itemArr,this.displayOptions, node => {
        if(node.value === itemArr[itemArr.length-1]){
          this.onChange(node)
          return
        }
      })


      this.query = ''
      this.$emit('on-change-object', this.values)
      // use setTimeout for #4786, can not use nextTick, because @on-find-selected use nextTick
      setTimeout(() => {
        this.handleClose()
      }, 0)
    },
    onFocus() {
      this.visible = true
    },
    // todo : 清空当前选择
    clearSingleSelect() {
      this.handleClose()
      if (this.itemDisabled) return false
      // 清空
      this.reset()

    },
    initOptions() {
      // console.log('init options')
      return this.options.map((node) => {
        let n = this.calcOptions(node)
        // this.$set(n, 'parent', null)
        n.parent = null
        return n
      })
    },
    onChange(changeItem, flag = false) {
      let isChecked = flag || !changeItem.checked
      // 子节点
      this.setChildren(changeItem, isChecked)
      // 前溯
      this.checkStrictly && this.setIndeterminate(changeItem, isChecked)

      const paths = this.optionsToPaths(this.displayOptions)

      this.values = paths.map((path) => ({
        label: path.map((opt) => opt.label).join(this.splitor),
        value: path.map((opt) => opt.value).join(this.splitor),
      }))

      // console.log('最终的值：', this.values)
      this.$emit('on-change-object', this.values)
      // this.$emit('update:modelValue', this.values)
    },
    optionsToPaths(options) {
      // Options tree to List<Path>
      // Path: List<Option>
      const paths = []
      const path = []
      const rec = (opt) => {
        const isLeaf = !opt.children || opt.children.length === 0
        path.push(opt)

        // 输出条件
        if (this.showCheckedStrategy === 'SHOW_ALL') {
          if (opt.checked) {
            paths.push([...path])
          }
        } else if (this.showCheckedStrategy === 'SHOW_PARENT') {
          if (opt.checked) {
            paths.push([...path])
            path.pop()
            return
          }
        } else {
          if (isLeaf && opt.checked) {
            paths.push([...path])
          }
        }

        if (!isLeaf) {
          opt.children.forEach(rec)
        }
        path.pop()
      }
      options.forEach(rec)
      return paths
    },
    calcOptions(node) {
      // console.log("in calc options", node)
      if (node.children && node.children.length) {
        node.children.forEach((item) => {
          this.calcOptions(item)
          // this.$set(item, 'parent', node)
          item.parent = node
        })
      }
      /* this.$set(node, 'checked', false)
      this.$set(node, 'active', false)
      this.$set(node, 'indeterminate', false)
      this.$set(node, 'selected', false) */
      /* node = {
        ...node,
        checked: false,
        active: false,
        indeterminate: false,
        selected: false,
      } */
      node.checked = false
      node.active = false
      node.indeterminate = false
      node.selected = false
      return node
    },



    removeTag(v, flag) {
      console.log('remove teg---------------', v.value)
      const valArray = v.value.split(this.splitor)
      const changeItem = valArray.reduce((opt, v, index) => {
        const ret = opt && opt.find((o) => v === String(o.value))
        if (index === valArray.length - 1) {
          return ret
        } else {
          return (ret || {}).children
        }
      }, this.displayOptions)
      if (changeItem) {
        this.onChange(changeItem)
      }
    },
    selectTag(v) {
      // console.log("selectTag")
      this.removeTag(v, true)
    },
    setChildren(item, isChecked) {
      item.checked = isChecked
      item.indeterminate = false
      // console.log('in set children', this.displayOptions)
      if (item.children && item.children.length) {
        item.children.forEach((child) => this.setChildren(child, isChecked))
      }
    },
    setIndeterminate(item, isChecked) {
      // console.log('set indeterminate', item.parent === this.displayOptions[1])
      if (item.parent) {
        if (isChecked) {
          if (
            item.parent.children.find(
              (child) => !child.checked || child.indeterminate
            )
          ) {
            item.parent.indeterminate = true
            item.parent.checked = false
          } else {
            item.parent.indeterminate = false
            item.parent.checked = true
          }
        } else {
          if (
            item.parent.children.find(
              (child) => child.checked || child.indeterminate
            )
          ) {
            item.parent.indeterminate = true
            item.parent.checked = false
          } else {
            item.parent.indeterminate = false
            item.parent.checked = false
          }
        }
        // console.log('in setindemidate: ', this.displayOptions)
        this.setIndeterminate(item.parent, isChecked)
      }
    },
    reset() {
      // console.log("reset")
      this.query = ''
      this.focusIndex = -1
      this.unchangedQuery = true
      this.values = []
      this.filterQueryChange = false
      // 清空值，并重置下拉框中的选项
      this.initOptions()
      this.$emit('on-change-object', this.values)
    },
  },
})
</script>
