<template>
  <div :class="classes" ref="cell">
    <template v-if="renderType === 'index'">
      <span>{{ column.indexMethod ? column.indexMethod(row, naturalIndex) : (naturalIndex + 1) }}</span>
    </template>
    <template v-if="renderType === 'selection'">
      <Checkbox :model-value="checked" @click.stop="handleClick" @on-change="toggleSelect" :disabled="disabled"></Checkbox>
    </template>
    <template v-if="renderType === 'draggable'">
      <Icon type="move"/>
    </template>
    <template v-if="renderType === 'current'">
      <Radio :model-value="highlight" @click.stop="handleClick" @on-change="currentSelect" :disabled="disabled" :label="''"></Radio>
    </template>
    <div class="haloe-table-cell-tree-level" v-if="showLevel" :style="treeLevelStyle"></div>
    <div
      class="haloe-table-cell-tree"
      :class="{ 'haloe-table-cell-tree-loading': childrenLoading }"
      v-if="showChildren"
      @click.prevent.stop="handleToggleTree">
      <Icon type="refresh" v-if="childrenLoading" class="haloe-load-loop" />
      <Icon type="add" v-else-if="!childrenExpand" />
      <Icon type="remove" v-else />
    </div>
    <div class="haloe-table-cell-tree haloe-table-cell-tree-empty" v-else-if="showTreeNode"></div>
    <template v-if="renderType === 'html'"><span v-html="row[column.key]"></span></template>
    <template v-if="renderType === 'normal'">
      <template v-if="column.tooltip">
        <Tooltip
          transfer
          :content="row[column.key]"
          :theme="column.tooltipTheme ? column.tooltipTheme : TableInstance.tooltipTheme"
          :disabled="!showTooltip"
          :max-width="column.tooltipMaxWidth ? column.tooltipMaxWidth : TableInstance.tooltipMaxWidth"
          class="haloe-table-cell-tooltip">
          <span ref="content" @mouseenter="handleTooltipIn" class="haloe-table-cell-tooltip-content">{{ row[column.key] }}</span>
        </Tooltip>
      </template>
      <span v-else>{{row[column.key]}}</span>
    </template>
    <template v-if="renderType === 'expand' && !row._disableExpand">
      <div :class="expandCls" @click="toggleExpand">
        <div class="haloe-table-cell-expand-icon-contain">
          <Icon :type="expandIconType"></Icon>
        </div>
      </div>
    </template>
    <table-expand
      v-if="renderType === 'render'"
      :row="row"
      :column="column"
      :index="index"
      :render="column.render"></table-expand>
    <table-slot
      v-if="renderType === 'slot'"
      :row="row"
      :column="column"
      :display="column.display || 'block'"
      :index="index"></table-slot>
  </div>
</template>
<script>
import TableExpand from './expand';
import TableSlot from './slot';
import Icon from '../icon/icon.vue';
import Checkbox from '../checkbox/checkbox.vue';
import Radio from '../radio/radio.vue';
// import Tooltip from '../tooltip/tooltip.vue';
import Tooltip from '../tooltip/tooltip-v2.vue';
import { isClient } from '../../utils/index';

export default {
  name: 'TableCell',
  components: { Icon, Checkbox, TableExpand, TableSlot, Tooltip, Radio },
  inject: ['TableInstance'],
  props: {
    prefixCls: String,
    row: Object,
    column: Object,
    naturalIndex: Number,    // index of rebuildData
    index: Number,           // _index of data
    checked: Boolean,
    highlight: Boolean,
    disabled: Boolean,
    expanded: Boolean,
    fixed: {
      type: [Boolean, String],
      default: false
    },
    // 是否为 tree 子节点
    treeNode: Boolean,
    treeLevel: {
      type: Number,
      default: 0
    }
  },
  data () {
    return {
      renderType: '',
      uid: -1,
      context: this.$parent.$parent.$parent.currentContext,
      showTooltip: false,  // 鼠标滑过overflow文本时，再检查是否需要显示
      expandIconType: 'add'
    };
  },
  computed: {
    classes () {
      return [
        `${this.prefixCls}-cell`,
        {
          [`${this.prefixCls}-hidden`]: !this.fixed && this.column.fixed && (this.column.fixed === 'left' || this.column.fixed === 'right'),
          [`${this.prefixCls}-cell-ellipsis`]: this.column.ellipsis || false,
          [`${this.prefixCls}-cell-with-expand`]: this.renderType === 'expand',
          [`${this.prefixCls}-cell-with-selection`]: this.renderType === 'selection'
        }
      ];
    },
    expandCls () {
      return [
        `${this.prefixCls}-cell-expand`,
        {
          [`${this.prefixCls}-cell-expand-expanded`]: this.expanded
        }
      ];
    },
    showChildren () {
      let status = false;
      if (this.renderType === 'html' || this.renderType === 'normal' || this.renderType === 'render' || this.renderType === 'slot') {
        const data = this.row;
        if ((data.children && data.children.length) || ('_loading' in data)) {
          if (this.column.tree) status = true;
        }
      }
      return status;
    },
    showTreeNode () {
      let status = false;
      if (this.renderType === 'html' || this.renderType === 'normal' || this.renderType === 'render' || this.renderType === 'slot') {
        if (this.column.tree && this.treeNode) status = true;
      }
      return status;
    },
    showLevel () {
      let status = false;
      if (this.renderType === 'html' || this.renderType === 'normal' || this.renderType === 'render' || this.renderType === 'slot') {
        if (this.column.tree && this.treeNode) status = true;
      }
      return status;
    },
    treeLevelStyle () {
      return {
        'padding-left': this.treeLevel * this.TableInstance.indentSize + 'px'
      };
    },
    childrenExpand () {
      const data = this.TableInstance.getDataByRowKey(this.row._rowKey);
      return data._isShowChildren;
    },
    childrenLoading () {
      const data = this.TableInstance.getDataByRowKey(this.row._rowKey);
      return '_loading' in data && data._loading;
    }
  },
  methods: {
    toggleSelect () {
      if (this.treeNode) {
        this.$parent.$parent.$parent.toggleSelect(this.index, this.row._rowKey);
      } else {
        this.$parent.$parent.$parent.toggleSelect(this.index);
      }
    },
    currentSelect () {
      this.$parent.$parent.$parent.clickCurrentRow(this.index);
    },
    toggleExpand () {
      this.expandIconType = (this.expandIconType === 'add') ? 'remove' : 'add'
      this.$parent.$parent.$parent.toggleExpand(this.index);
    },
    handleClick () {
      // 放置 Checkbox 冒泡
    },
    handleTooltipIn () {
      if (!isClient) return;
      const $content = this.$refs.content;
      let range = document.createRange();
      range.setStart($content, 0);
      range.setEnd($content, $content.childNodes.length);
      const rangeWidth = range.getBoundingClientRect().width;
      this.showTooltip = rangeWidth > $content.offsetWidth;
      range = null;
    },
    handleToggleTree () {
      this.$parent.$parent.$parent.toggleTree(this.row._rowKey);
    },
    // 改为 table-body 中触发，因为 cell 有padding间距
    // handleCellClick (event) {
    // handleCellClick (event) {
    //     this.$parent.$parent.$parent.$emit('on-cell-click', this.row, this.column, this.row[this.column.key], event);
    // }
  },
  created () {
    this.expandIconType = this.row._expanded ? 'remove' : 'add'

    if (this.column.type === 'index') {
      this.renderType = 'index';
    } else if (this.column.type === 'selection') {
      this.renderType = 'selection';
    } else if (this.column.type === 'draggable') {
      this.renderType = 'draggable';
    } else if (this.column.type === 'current') {
      this.renderType = 'current';
    } else if (this.column.type === 'html') {
      this.renderType = 'html';
    } else if (this.column.type === 'expand') {
      this.renderType = 'expand';
    } else if (this.column.render) {
      this.renderType = 'render';
    } else if (this.column.slot) {
      this.renderType = 'slot';
    } else {
      this.renderType = 'normal';
    }
  }
};
</script>
