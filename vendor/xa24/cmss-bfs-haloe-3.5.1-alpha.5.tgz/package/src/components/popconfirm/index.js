import Popconfirm from './popconfirm.vue';

export default Popconfirm;
