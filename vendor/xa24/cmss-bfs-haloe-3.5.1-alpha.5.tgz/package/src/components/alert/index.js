import Alert from './alert.vue';
// export default Alert;

const withInstall = (comp) => {
  const c = comp;
  c.install = function (app) {
    // app.component(c.displayName || c.name, comp);
    app.component('e'+ c.name, comp);
  };

  return comp
};

export default withInstall(Alert);