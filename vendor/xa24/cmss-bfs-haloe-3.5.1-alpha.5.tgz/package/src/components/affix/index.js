/*
 * @Description: Stay hungry，Stay foolish
 * @Author: ''
 * @Date: 2023-09-14 15:36:39
 * @LastEditTime: 2023-10-11 23:08:49
 * @LastEditors: ''
 */
import Affix from './affix.vue';
// export default Affix;

const withInstall = (comp) => {
  const c = comp;
  c.install = function (app) {
    // app.component(c.displayName || c.name, comp);
    app.component('e'+ c.name, comp);
  };

  return comp
};

export default withInstall(Affix);
