import InputGroup from '../input/input-group.vue';

export default InputGroup;