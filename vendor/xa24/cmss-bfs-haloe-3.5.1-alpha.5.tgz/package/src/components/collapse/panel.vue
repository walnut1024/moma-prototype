<template>
  <div :class="itemClasses">
    <div
      :class="headerClasses"
      @click="toggle">
      <Icon
        type="chevron-right"
        v-if="!hideArrow"></Icon>
      <slot></slot>
    </div>
    <collapse-transition v-if="mounted">
      <div
        :class="contentClasses"
        v-show="isActive">
        <div :class="boxClasses"><slot name="content"></slot></div>
      </div>
    </collapse-transition>
  </div>
</template>
<script>
import Icon from '../icon/icon.vue';
// import CollapseTransition from './collapse-transition.vue';
import CollapseTransition from '../base/collapse-transition.vue'
const prefixCls = 'haloe-collapse';

export default {
  name: 'Panel',
  components: { Icon, CollapseTransition },
  props: {
    name: {
      type: String
    },
    hideArrow: {
      type: Boolean,
      default: false
    },
    disabled: {
      type: Boolean,
      default: false
    }
  },
  inject: ['collapseValue', 'collapseToggle'],
  data () {
    return {
      index: 0, // use index for default when name is null
      // isActive: false,
      mounted: false
    };
  },
  computed: {
    isActive () {
      const name = this.name || this.index.toString();
      const currentValue = this.collapseValue();
      return currentValue ? currentValue.includes(name) : false;
    },
    itemClasses () {
      return [
        `${prefixCls}-item`,
        {
          [`${prefixCls}-item-active`]: this.isActive,
          [`${prefixCls}-item-disabled`]: this.disabled,
          [`${prefixCls}-item-no-arrow`]: this.hideArrow,
        }
      ];
    },
    headerClasses () {
      return `${prefixCls}-header`;
    },
    contentClasses () {
      return `${prefixCls}-content`;
    },
    boxClasses () {
      return `${prefixCls}-content-box`;
    }
  },
  methods: {
    toggle () {
      if (!this.disabled) {
        this.collapseToggle({
          name: this.name || this.index,
          isActive: this.isActive
        });
      }
    }
  },
  mounted () {
    this.mounted = true;
  },
};
</script>
