export const bodyContentType = {
  'LIST': 'list',
  'TABLE': 'table',
  'TREE': 'tree'
}