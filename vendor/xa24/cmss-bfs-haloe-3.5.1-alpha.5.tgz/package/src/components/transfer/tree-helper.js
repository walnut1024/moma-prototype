const insertNodes = (sourceTree: [], newNodes: [], targetTree: []) => {
  let sourceRootNode, targetRootNode
  if(!targetTree.length) {
    sourceRootNode = sourceTree[0]

  } else {

  }
}

const deleteNodes = (sourceTree: [], delnodes: []) => {

}

// 根据选中的树节点，生成被选中的树结构
const getTreeNodes = (keys: [], nodes: []) => {

}