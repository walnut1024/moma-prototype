<script>
import { computed, h } from 'vue';
import List from './list.vue';
import Operation from './operation.vue';
import Locale from '../../mixins/locale';
import mixinsForm from '../../mixins/form';
import { bodyContentType } from './constant';
const prefixCls = 'haloe-transfer';
export default {
  name: 'Transfer',
  mixins: [ Locale, mixinsForm ],
  emits: ['on-change', 'on-selected-change'],
  provide () {
    return {
      TransferInstance: this
    }
  },
  render () {
    const defaultSlot = this.$slots.default ? this.$slots.default() : '';
    return h('div', {
      'class': this.classes
    }, [
      h(List, {
        ref: 'left',
        prefixCls: this.prefixCls + '-list',
        data: this.leftData,
        renderFormat: this.renderFormat,
        checkedKeys: this.leftCheckedKeys,
        validKeysCount: this.leftValidKeysCount,
        listStyle: this.listStyle,
        title: this.localeTitles[0],
        filterable: this.filterable,
        filterPlaceholder: this.localeFilterPlaceholder,
        filterMethod: this.filterMethod,
        notFoundText: this.localeNotFoundText,
        asTable: this.asTable,
        contentType: this.contentType,
        columns: this.columns,
        showFooter: this.showFooter,
        disabled:this.disabled,
        'onOn-checked-keys-change':this.handleLeftCheckedKeysChange
      }, () => defaultSlot),
      h(Operation, {
        prefixCls: this.prefixCls,
        operations: this.operations,
        leftActive: this.leftValidKeysCount > 0,
        rightActive: this.rightValidKeysCount > 0,
        reverseOperation: this.reverseOperation
      }),
      h(List, {
        ref: 'right',
        prefixCls: this.prefixCls + '-list',
        data: this.rightData,
        renderFormat: this.renderFormat,
        checkedKeys: this.rightCheckedKeys,
        validKeysCount: this.rightValidKeysCount,
        listStyle: this.listStyle,
        title: this.localeTitles[1],
        filterable: this.filterable,
        filterPlaceholder: this.localeFilterPlaceholder,
        filterMethod: this.filterMethod,
        notFoundText: this.localeNotFoundText,
        asTable: this.asTable,
        contentType: this.contentType,
        columns: this.columns,
        showFooter: this.showFooter,
        disabled:this.disabled,
        'onOn-checked-keys-change':this.handleRightCheckedKeysChange
      }, () => defaultSlot)
    ]);
  },
  props: {
    data: {
      type: Array,
      default () {
        return [];
      }
    },
    renderFormat: {
      type: Function,
      default (item) {
        return item.label || item.key;
      }
    },
    targetKeys: {
      type: Array,
      default () {
        return [];
      }
    },
    selectedKeys: {
      type: Array,
      default () {
        return [];
      }
    },
    listStyle: {
      type: Object,
      default () {
        return {};
      }
    },
    titles: {
      type: Array
    },
    operations: {
      type: Array,
      default () {
        return [];
      }
    },
    filterable: {
      type: Boolean,
      default: false
    },
    filterPlaceholder: {
      type: String
    },
    filterMethod: {
      type: Function,
      default (data, query) {
        if (this.asTable) {
          const type = ('name' in data) ? 'name' : 'key'
          return data[type].indexOf(query) > -1
        }
        const type = ('label' in data) ? 'label' : 'key'
        return data[type].indexOf(query) > -1
      }
    },
    notFoundText: {
      type: String
    },
    // 4.2.0
    // 反转两个按钮
    reverseOperation: {
      type: Boolean,
      default: false
    },
    asTable: {
      type: Boolean,
      default: false
    },
    contentType: {
      type: String,
    },
    columns: {
      type: Array,
      default () {
        return []
      }
    },
    showFooter: {
      type: Boolean,
      default: false,
    },
    disabled:{
      type: Boolean,
      default: false,
    }
  },
  data () {
    return {
      prefixCls: prefixCls,
      leftData: [],
      rightData: [],
      leftCheckedKeys: [],
      rightCheckedKeys: []
    };
  },
  computed: {
    classes () {
      return [
        `${prefixCls}`
      ];
    },
    computedBodyContentType () {
      if(this.contentType) {
        return this.contentType
      } else {
        return this.asTable ? bodyContentType.TABLE : bodyContentType.LIST
      }
    },
    bodyContentTypeIsTree () {
      return this.computedBodyContentType === bodyContentType.TREE
    },
    leftValidKeysCount () {
      if(!this.bodyContentTypeIsTree) {
        return this.getValidKeys('left').length;
      } else {
        return this.leftCheckedKeys.length
      }
    },
    rightValidKeysCount () {
      if(!this.bodyContentTypeIsTree) {
        return this.getValidKeys('right').length;
      } else {
        return this.rightCheckedKeys.length
      }
    },
    localeFilterPlaceholder () {
      if (this.filterPlaceholder === undefined) {
        return this.t('i.transfer.filterPlaceholder');
      } else {
        return this.filterPlaceholder;
      }
    },
    localeNotFoundText () {
      if (this.notFoundText === undefined) {
        return this.t('i.transfer.notFoundText');
      } else {
        return this.notFoundText;
      }
    },
    localeTitles () {
      if (this.titles === undefined) {
        return [this.t('i.transfer.titles.source'), this.t('i.transfer.titles.target')];
      } else {
        return this.titles;
      }
    }
  },
  methods: {
    getValidKeys (direction) {
      if(!this.bodyContentTypeIsTree) {
        return this[`${direction}Data`].filter(data => !data.disabled && this[`${direction}CheckedKeys`].indexOf(data.key) > -1).map(data => data.key);
      } else {
        return this[`${direction}CheckedKeys`]
      }
    },
    splitData (init = false) {
      this.leftData = [...this.data];
      this.rightData = [];
      if (this.targetKeys.length > 0) {
        this.targetKeys.forEach((targetKey) => {
          const filteredData = this.leftData.filter((data, index) => {
            if (data.key === targetKey) {
              this.leftData.splice(index, 1);
              return true;
            }
            return false;
          });
          if (filteredData && filteredData.length > 0) this.rightData.push(filteredData[0]);
        });
      }
      if (init) {
        this.splitSelectedKey();
      }
    },
    splitSelectedKey () {
      const selectedKeys = this.selectedKeys;
      if (selectedKeys.length > 0) {
        this.leftCheckedKeys = this.leftData
          .filter(data => selectedKeys.indexOf(data.key) > -1)
          .map(data => data.key);
        this.rightCheckedKeys = this.rightData
          .filter(data => selectedKeys.indexOf(data.key) > -1)
          .map(data => data.key);
      }
    },
    moveTo (direction) {
      const targetKeys = this.targetKeys; // 显示在右侧框数据的key集合
      const opposite = direction === 'left' ? 'right' : 'left'; // 穿梭源方向
      // 要穿梭的节点数据
      const moveKeys = this.getValidKeys(opposite); 
      let newTargetKeys 
      if(!this.bodyContentTypeIsTree) {
        // 穿梭后，目标方向节点的数据
        newTargetKeys = direction === 'right' ?
          moveKeys.concat(targetKeys) :
          targetKeys.filter(targetKey => !moveKeys.some(checkedKey => targetKey === checkedKey));
      } else {
        // 插入树节点
        const targeTree = direction === 'right' ? this.targetKeys : this.leftData;
        const sourceTree = direction === 'right' ? this.leftData : this.targetKeys;
        // TODO 将选中的节点穿梭至目标节点
      }
      // 穿梭源节点的全选状体取消
      this.$refs[opposite].toggleSelectAll(false);
      // 事件触发到外部
      this.$emit('on-change', newTargetKeys, direction, moveKeys);
      // 如果在表单中，触发表单的change事件
      this.handleFormItemChange('change', {
        tarketKeys: newTargetKeys,
        direction: direction,
        moveKeys: moveKeys
      });
    },
    handleLeftCheckedKeysChange (keys) {
      this.leftCheckedKeys = keys;
    },
    handleRightCheckedKeysChange (keys) {
      this.rightCheckedKeys = keys;
    },
    handleCheckedKeys () {
      const sourceSelectedKeys = this.getValidKeys('left');
      const targetSelectedKeys = this.getValidKeys('right');
      this.$emit('on-selected-change', sourceSelectedKeys, targetSelectedKeys);
    }
  },
  watch: {
    targetKeys () {
      this.splitData(false);
    },
    data () {
      this.splitData(false);
    }
  },
  mounted () {
    this.splitData(true);
  }
};
</script>
