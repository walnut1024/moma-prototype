import { h } from 'vue';
export default {
  name: 'SliderMarker',
  props: {
    mark: {
      type: [String, Object]
    },
    markType:{
      type: Boolean
    }
  },
  render () {
    let label = typeof this.mark === 'string' ? this.mark : [this.mark.label];

    return h('div', {
      class: this.markType ? 'haloe-slider-marks-item-type': 'haloe-slider-marks-item',
      style: this.mark.style || {}
    }, label);
  }
};
