import Title from '../layout/title.vue';

export default Title;
