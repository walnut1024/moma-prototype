import Ellipsis from './ellipsis.vue';
// import Ellipsis from './ellipsis-v1.vue';
export default Ellipsis;
