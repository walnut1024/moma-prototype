// import Tooltip from './tooltip.vue';
import Tooltip from "./tooltip-v2.vue"
export default Tooltip;
