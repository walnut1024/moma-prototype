import Notification from '../base/notification';

const prefixCls = 'haloe-message';
const iconPrefixCls = 'haloe-icon';
const prefixKey = 'haloe_message_key_';

const defaults = {
  top: 24,
  duration: 1.5,
  background: false,
  dark: false
};

let messageInstance;
let name = 1;

const iconTypes = {
  'info': 'info-circle-filled',
  'success': 'check-circle-filled',
  'warning': 'warning-filled', 
  'error': 'close-circle-filled',
  'help': 'help-circle-filled',
  'loading': 'jiazaizhong'
};

const transitionName = 'move-up';

function getMessageInstance () {
  messageInstance = messageInstance || Notification.newInstance({
    prefixCls: prefixCls,
    styles: {
      top: `${defaults.top}px`
    },
    transitionName
  });

  return messageInstance;
}

function notice (
  content = '',
  duration = defaults.duration,
  type,
  onClose = function () {},
  closable = false,
  render = function () {},
  background = defaults.background,
  dark = defaults.dark
) {
  const iconType = iconTypes[type];

  // if loading
  const loadCls = type === 'loading' ? ' haloe-load-loop' : '';

  let instance = getMessageInstance();

  instance.notice({
    name: `${prefixKey}${name}`,
    duration: duration,
    styles: {},
    transitionName,
    content: `
            <div class="${prefixCls}-custom-content ${prefixCls}-${type}">
                <i class="${iconPrefixCls} ${iconPrefixCls}-${iconType} ${loadCls}"></i>
                <span>${content}</span>
            </div>
        `,
    render: render,
    onClose: onClose,
    closable: closable,
    type: 'message',
    msgType: type,
    background: background,
    dark: dark
  });

  // 用于手动消除
  return (function () {
    let target = name++;

    return function () {
      instance.remove(`${prefixKey}${target}`);
    };
  })();
}

export default {
  name: 'Message',

  info (options) {
    return this.message('info', options);
  },
  success (options) {
    return this.message('success', options);
  },
  warning (options) {
    return this.message('warning', options);
  },
  error (options) {
    return this.message('error', options);
  },
  help (options) {
    return this.message('help', options);
  },
  loading (options) {
    return this.message('loading', options);
  },
  message(type, options){
    if (typeof options === 'string') {
      options = {
        content: options
      };
    }
    return notice(options.content, options.duration, type, options.onClose, options.closable, options.render, options.background, options.dark);
  },
  config (options) {
    if (options.top || options.top === 0) {
      defaults.top = options.top;
    }
    if (options.duration || options.duration === 0) {
      defaults.duration = options.duration;
    }
    if (options.background) {
      defaults.background = options.background
    }
    if (options.dark) {
      defaults.dark = options.dark
    }
  },
  destroy () {
    let instance = getMessageInstance();
    messageInstance = null;
    instance.destroy('haloe-message');
  }
};
