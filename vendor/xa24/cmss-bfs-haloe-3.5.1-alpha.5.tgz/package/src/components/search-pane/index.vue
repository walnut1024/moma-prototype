<!--
 * @Description: Stay hungry，Stay foolish
 * @Author: ''
 * @Date: 2023-06-09 08:38:08
 * @LastEditTime: 2023-10-11 22:05:35
 * @LastEditors: ''
-->
<template>
  <component
    :is="compName"
    v-bind="$attrs"
    v-on="$attrs"
  >
    <slot></slot>
  </component>
</template>
<script>
import Complex from './complex'
import Simple from './simple'
import Adapter from './adapter'
import { oneOf } from '../../utils/assist'
export default {
  inheritAttrs: false,
  props: {
    type: {
      validator (value) {
        return oneOf(value, ['simple', 'complex', 'adaptive'])
      },
      default: 'adaptive'
    }
  },
  components: {
    Complex,
    Simple,
    Adapter
  },
  computed: {
    compName () {
      return this.type === 'complex' ? 'Complex' : this.type === 'simple' ? 'Simple' : 'Adapter'
    }
  }
}
</script>
