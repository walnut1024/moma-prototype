<template>
  <div class="adaptive-item">
    <slot></slot>
  </div>
</template>
