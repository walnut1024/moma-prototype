import SearchPane from './index.vue';

export default SearchPane;