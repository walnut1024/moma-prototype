import Watermark from './watermark.vue';

export default Watermark;
