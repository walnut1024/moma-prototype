<template>
  <div :class="wrapClasses"><slot></slot></div>
</template>
<script setup>
import {computed} from 'vue'

const prefixCls = 'haloe-layout';

let wrapClasses = computed(()=>{
  return `${prefixCls}-footer`;
})

</script>
