<template>
  <div :class="wrapClasses"><slot></slot></div>
</template>
<script setup>
import {computed,getCurrentInstance, onMounted,ref} from 'vue'

const prefixCls = 'haloe-layout';

const instance = getCurrentInstance()

let hasSider = ref(false)

/**
 * 判断是否有sider组件
 */
function findSider () {
  const defaults = instance.slots.default()
  return defaults.some(child=>{
    return child.type.name === "Sider"
  })
}

onMounted(()=>{
  hasSider.value = findSider()
})


const wrapClasses = computed(()=>{
  return [
    `${prefixCls}`,
    {[`${prefixCls}-has-sider`]: hasSider.value}
  ]
})


</script>
