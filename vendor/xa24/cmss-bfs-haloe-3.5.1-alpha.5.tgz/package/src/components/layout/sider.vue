<template>
  <div
    :class="wrapClasses"
    :style="wrapStyles">
    <div :class="childClasses">
      <slot></slot>
    </div>
    <slot name="trigger">
      <div v-show="showMiddleTrigger" :class="triggerClasses" @click="toggleCollapse">
        <i :class="triggerIconClasses"></i>
      </div>
    </slot>
  </div>
</template>
<script>
export default {
  name: 'Sider'
}
</script>
<script setup>
import { defineProps,ref,computed,onMounted, watch, toRefs, defineEmits  } from 'vue';

const props = defineProps({
  modelValue: { // 双向绑定,true表示合并
    type: Boolean,
    default: false
  },
  width: { // Sider宽度
    type: [Number, String],
    default: 180
  },
  collapsible: { // 是否可合并
    type: Boolean,
    default: false
  },
  collapsedWidth: { // 合并后宽度
    type: [Number, String],
    default: 64
  },
  hideTrigger: { // 是否隐藏触发器
    type: Boolean,
    default: false
  },
  defaultCollapsed: { // 默认是否合并
    type: Boolean,
    default: false
  }
})

const emits = defineEmits(["update:modelValue","on-collapse","input"])

const prefixCls = ref("haloe-layout-sider")

let {modelValue,width,collapsible,hideTrigger,defaultCollapsed,collapsedWidth} = toRefs(props)

/**
 * 根元素类
 */
const wrapClasses = computed(()=>{
  return [
    `${prefixCls.value}`,
    siderWidth.value ? '' : `${prefixCls.value}-zero-width`, //宽度为0的样式，超出截断
    modelValue.value ? `${prefixCls.value}-collapsed` : '' // 按钮旋转180度
  ];
})

/**
 * 根元素样式控制
 */
const wrapStyles = computed(()=>{
  return {
    width: `${siderWidth.value}px`,
    minWidth: `${siderWidth.value}px`,
    maxWidth: `${siderWidth.value}px`,
    flex: `0 0 ${siderWidth.value}px`
  };
})

/**
 * 中间按钮样式
 */
const triggerClasses = computed(()=>{
  return [
    `${prefixCls.value}-trigger`,
    modelValue.value ? `${prefixCls.value}-trigger-collapsed` : '',
  ];
})


/**
 * 子元素的父元素类
 */
const childClasses = computed (()=>{
  return `${prefixCls.value}-children`;
})


/**
 * 中间切换按钮样式切换
 */
const triggerIconClasses = computed (()=>{
  return [
    'haloe-layout-icon',
    `${prefixCls.value}-trigger-icon`,
  ];
})

/**
 *动态控制sidebar的宽度
 */
const siderWidth = computed (()=>{
  return collapsible.value ? (modelValue.value ? parseInt(collapsedWidth.value) : parseInt(width.value)) : width.value;
})



/**
 * 是否已显示中间的切换按钮
 */
const showMiddleTrigger = computed(()=>{
  return collapsible.value ? !hideTrigger.value : false;
})

/**
 * 切换开启闭合
 */
function toggleCollapse () {
  let value = collapsible.value ? !modelValue.value : false;
  emits('update:modelValue', value);
}


/**
   * 监听展开闭合
   */
watch(modelValue,(stat)=>{
  emits("on-collapse",stat)
})

onMounted(()=>{
  // 页面加载处理展开和闭合
  if (defaultCollapsed.value) {
    emits('input', defaultCollapsed.value);
  }
})


/**
 * 对外暴露切换按钮函数，使用者可自定义切换按钮
 */
defineExpose({toggleCollapse})

</script>
