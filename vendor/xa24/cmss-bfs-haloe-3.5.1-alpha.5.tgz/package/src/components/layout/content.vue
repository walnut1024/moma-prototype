<template>
  <div :class="wrapClasses"><slot></slot></div>
</template>
<script setup>
import {computed} from 'vue'

const prefixCls = 'haloe-layout';

/**
 * 父元素样式
 */
let wrapClasses = computed(()=>{
  return `${prefixCls}-content`;
})
</script>
