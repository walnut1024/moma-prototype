<template>
  <div :class="classes">
    <slot></slot>
  </div>
</template>
<script>
import { getCurrentInstance } from 'vue';
import { oneOf } from '../../utils/assist';

const prefixCls = 'haloe-input-group-wrapper';

export default {
  name: 'eInputGroup',
  props: {
    size: {
      validator (value) {
        return oneOf(value, ['small', 'middle', 'large', 'default']);
      },
      default () {
        const global = getCurrentInstance().appContext.config.globalProperties;
        return !global.$HALOE || global.$HALOE.size === '' ? 'default' : global.$HALOE.size;
      }
    }
  },
  computed: {
    classes() {
      return [
        `${prefixCls}`,
        {
          [`${prefixCls}-${this.size}`]: !!this.size,
        },
      ]
    },
  },
};
</script>
