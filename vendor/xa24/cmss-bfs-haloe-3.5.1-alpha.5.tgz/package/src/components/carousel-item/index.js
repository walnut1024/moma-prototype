// import CarouselItem from '../carousel/carousel-item';
import CarouselItem from '../carousel/carousel-item-v2.vue';
export default CarouselItem;