import Tag from './tag.vue'
// import Tag from "./tag-v2.vue";
export default Tag
