// import TimePicker from './picker.vue';
import TimePicker from '../date-picker/picker/time-picker';
export default TimePicker;
