<template>
  <div :class="[prefixCls + '-body-wrapper']" @mousedown.prevent>
    <div :class="[prefixCls + '-body']">
      <div :class="[timePrefixCls + '-header']" v-if="showDate">{{ visibleDate }}</div>
      <div :class="[prefixCls + '-content']">
        <time-spinner
          ref="timeSpinner"
          :show-seconds="showSeconds"
          :show-minutes="showMinutes"
          :steps="steps"
          :timeStyle="timeStyle[0]"
          :hours="timeSlots[0]"
          :minutes="timeSlots[1]"
          :seconds="timeSlots[2]"
          :duodecimal="duodecimal"
          :disabled-hours="disabledHMS.disabledHours"
          :disabled-minutes="disabledHMS.disabledMinutes"
          :disabled-seconds="disabledHMS.disabledSeconds"
          :hide-disabled-options="hideDisabledOptions"
          @on-style-change="handleStyleChange"
          @on-change="handleChange"
          @on-pick-click="handlePickClick"></time-spinner>
      </div>
      <Confirm v-if="confirm"  @on-pick-clear="handlePickClear" @on-pick-success="handlePickSuccess"></Confirm>
    </div>
  </div>
</template>
<script>
import { nextTick } from 'vue';

import TimeSpinner from './time-spinner.vue';
import Options from '../config/time-mixins';

import Confirm from '../../date-picker/base/confirm.vue'
import Mixin from '../config/panel-mixin';
import Locale from '../../../mixins/locale';

import { initTimeDate } from '../config/util';

const prefixCls = 'haloe-picker-panel';
const timePrefixCls = 'haloe-time-picker';

const capitalize = (str) => str[0].toUpperCase() + str.slice(1);
const mergeDateHMS = (date, hours, minutes, seconds) => {
  const newDate = new Date(date.getTime());
  newDate.setHours(hours);
  newDate.setMinutes(minutes);
  newDate.setSeconds(seconds);
  return newDate;
};
const unique = (el, i, arr) => arr.indexOf(el) === i;
const returnFalse = () => false;

export default {
  name: 'TimePickerPanel',
  mixins: [ Mixin, Locale, Options ],
  components: { TimeSpinner,Confirm },
  emits: ['on-pick', 'on-style'],
  props: {
    disabledDate: {
      type: Function,
      default: returnFalse
    },
    duodecimal: {
      type: Boolean,
      default: false,
    },
    timeStyle: {
      type: Array,
      default() {
        return []
      },
    }
    // confirm:{
    //   type: Boolean,
    //   default: false,
    // },
  },
  data () {
    return {
      prefixCls: prefixCls,
      timePrefixCls: timePrefixCls,
      date: !this.modelValue || !this.modelValue[0] ? initTimeDate() : this.modelValue ,
      showDate: false
    };
  },
  computed: {
    showSeconds () {
      //fix Hour & Minute Picker bug,show seconds when has "ss"
      return !(this.format || '').match(/HH/) || !!(this.format || '').match(/ss/);
    },
    showMinutes () {
      //fix Hour & Minute Picker bug,show seconds when has "ss"
      return !(this.format || '').match(/HH/) || !!(this.format || '').match(/mm/);
    },
    visibleDate () { // TODO
      const date = this.date;
      const month = date.getMonth() + 1;
      const tYear = this.t('i.datepicker.year');
      const tMonth = this.t(`i.datepicker.month${month}`);
      return `${date.getFullYear()}${tYear} ${tMonth}`;
    },
    timeSlots(){
      if (!this.modelValue || !this.modelValue[0]) return [];
      return ['getHours', 'getMinutes', 'getSeconds'].map(slot => new Date(this.date)[slot]());
    },
    disabledHMS(){
      const disabledTypes = ['disabledHours', 'disabledMinutes', 'disabledSeconds'];
      if (this.disabledDate === returnFalse || !this.modelValue[0]) {
        const disabled = disabledTypes.reduce(
          (obj, type) => (obj[type] = this[type], obj), {}
        );
        return disabled;
      } else {
        const slots = [24, 60, 60];
        const disabled = ['Hours', 'Minutes', 'Seconds'].map(type => this[`disabled${type}`]);
        const disabledHMS = disabled.map((preDisabled, j) => {
          const slot = slots[j];
          const toDisable = preDisabled;
          for (let i = 0; i < slot; i+= (this.steps[j] || 1)){
            const hms = this.timeSlots.map((slot, x) => x === j ? i : slot);
            const testDateTime = mergeDateHMS(this.date, ...hms);
            if (this.disabledDate(testDateTime, true)) toDisable.push(i);
          }
          return toDisable.filter(unique);
        });
        return disabledTypes.reduce(
          (obj, type, i) => (obj[type] = disabledHMS[i], obj), {}
        );
      }
    }
  },
  watch: {
    visible(val){
      if (val) {
        nextTick(() => {
          const spinner = this.$refs.timeSpinner;
          spinner.updateScroll();
        });
      }
    },
    modelValue (dates) {
      let newVal = dates[0] || initTimeDate();
      newVal = new Date(newVal);
      this.date = newVal;
    }
  },
  methods: {
    handleStyleChange (date) {
      let style = [date]
      this.$emit('on-style', style)
    },
    handleChange (date, emit = true) {
      const newDate = new Date(this.date);
      Object.keys(date).forEach(
        type => newDate[`set${capitalize(type)}`](date[type])
      );
      if (emit) this.$emit('on-pick', newDate, 'time');
    },
  },
  mounted () {
    if (this.$parent && this.$parent.$options.name === 'DatePicker') this.showDate = true;
  }
};
</script>
